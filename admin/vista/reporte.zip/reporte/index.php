<!DOCTYPE html>
 
<html lang="es">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="icon" href="../../favicon.ico" type="image/x-icon">
    <title>Reporte de somatotipo</title>
    <!-- Bootstrap Core Css -->
	<link href="../../plugins/bootstrap/css/bootstrap.css" rel="stylesheet" type="text/css">
</head>
 
<body>
    <div id="chartContainer" style="height: 150mm; width: 200mm;margin:0px;position: relative;"></div>
    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <!-- Jquery Core Js -->
	<script src="../../plugins/jquery/jquery.min.js"></script>
	<!-- Bootstrap Core Js -->
	<script src="../../plugins/bootstrap/js/bootstrap.js"></script>
    <script src="index.js"></script>
    <script src="../../lib.js"></script>
    <script src="../../canvasjs.min.js"></script>
    <script src="../../html2canvas.min.js"></script>
    <script src="../../jsPDF/dist/jspdf.debug.js"></script>
</body>
</html>